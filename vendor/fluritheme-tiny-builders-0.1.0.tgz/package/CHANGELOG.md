# Changelog

## 0.1.0

- A coordinated crew of up to twelve named workers with four roles, reserved jobs, prerequisite tasks and finite materials.
- Four distinct projects: a masonry tower, timber bridge, planter garden and painted signboard. Each is assembled piece by piece.
- Delivery trucks, visible stock, crane lifting and lowering, temporary scaffold decks and ladder climbing.
- Articulated walking, carrying, hammering, painting, coffee drinking, waving and celebrations. Dust, demolition chips and confetti use bounded particle pools.
- Repair preserves foundations and reschedules damaged dependencies. Demolition clears before the next project starts.
- Real DOM surface anchors, responsive replanning, nested-scroll tracking, scoped roots and a document workbench fallback.
- Interactive name labels, day/night headlamps, a typed event API, immutable snapshots and deterministic seeds.
- SSR-safe native modules, no runtime dependencies or network calls, reduced-motion support, offscreen/hidden pausing and complete resource cleanup.
- Commercial from the first release under the Fluri Themes Commercial License.
