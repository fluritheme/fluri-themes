# Changelog

## 0.1.0

First Black Cat edition, revised after motion review: four-paw contact gait, crouch before jumps, ballistic arcs, landing compression, gradual sit/sleep/turn transitions and a pre-populated playground. Includes articulated walking, pointer stalking, surface-aware jumps, yarn play, grooming, hide-and-peek, affectionate reactions and curled-up sleep. Document coordinates, bounded previews, touch interaction, motion preferences, explicit pause/resume and complete teardown. Commercial from the first release.
