# Black Cat by Fluri

A little trouble. Excellent company.

A tiny black cat that treats your website like home: real perches, careful jumps, curious eyes, hide-and-peek, yarn pounces, grooming and extremely important naps. Original vector artwork, animated at runtime. Zero runtime dependencies. No CSS imports, network calls, cookies, tracking or activation.

[Try Black Cat](https://cat.fluri.xyz/) · [All Fluri themes](https://fluri.xyz/) · [Lifetime licence](https://fluri.xyz/license/)

![Walking, playing and sleeping](https://cat.fluri.xyz/previews/black-cat.gif)

![Black Cat on a real page surface](https://cat.fluri.xyz/previews/black-cat-desktop.png)

## Try it

Black Cat is a new commercial theme, not yet listed on npm. Download the [private evaluation archive](https://cat.fluri.xyz/downloads/fluritheme-black-cat-0.1.0.tgz), then install the local file:

```sh
npm install ./fluritheme-black-cat-0.1.0.tgz
```

```ts
import { createCat } from '@fluritheme/black-cat';

const cat = createCat();

// Optional: choose explicit surfaces and hiding places in your HTML.
// <article data-cat-surface data-cat-hide>...</article>

cat.play(); // Introduce a ball of yarn.
cat.sleep(); // Finish the current jump, then curl up.
cat.wake();
cat.hide(); // Hide behind a nearby visible object.
cat.pet(); // A little affection.
cat.perch('#my-card');

// On unmount or navigation:
cat.destroy();
```

Buttons, headings, cards and articles become perches by default. Explicit `data-cat-surface` elements take priority. The effect never moves, deletes or reparents host content; hiding uses the card’s measured outline as a clipping mask. Pointer listeners are passive and the decorative canvas never intercepts clicks or scrolling.

## A world of his own

```ts
const cat = createCat({
  root: document.querySelector<HTMLElement>('#preview')!,
  surfaces: '[data-cat-surface]',
  hidingSpots: '[data-cat-hide]',
  size: 120,
  speed: 1,
  personality: 'curious', // 'playful' | 'sleepy'
  motion: 'system', // 'full' | 'none'
  seed: 41,
});
```

A document root explores the page; an element root clips the cat to that area. `size` is 48–240 CSS pixels; `speed` is 0.25–3. `autoStart: false` starts paused. `zIndex` defaults to 40. A fixed seed makes behaviour reproducible for demonstrations. Avoid placing perches inside transformed or continuously animated containers: those need `refresh()` after layout changes.

`pause()`, `resume()`, `refresh()` and `destroy()` support route changes and visibility controls. `getState()` reports phase, document position, current surface, hiding state and yarn position. `play()`, `hide()` and `perch()` return whether the action was accepted; wait for a landing before asking for yarn or hiding. `sleep()` queues a nap if he is already jumping. `wake()` lets an existing jump finish.

```ts
const unsubscribe = cat.on('phase', ({ phase, position }) => {
  console.log(phase, position);
});
unsubscribe();
```

Events: `ready`, `phase`, `land`, `play`, `sleep`, `error`. Listener failures are isolated from the animation. `error` reports a listener failure without exposing browser data.

## React

```tsx
import { useEffect } from 'react';
import { createCat } from '@fluritheme/black-cat';

export function WebsiteCat() {
  useEffect(() => {
    const cat = createCat();
    return () => cat.destroy();
  }, []);
  return null;
}
```

Use the same mount/unmount lifecycle with Vue, Svelte, Astro or plain JavaScript. Importing the package during SSR is safe; create it on the client to render the cat.

## Motion with a little weight

A four-paw contact gait keeps feet planted through each stance. Jumps include a short crouch, a ballistic arc and landing compression. Sitting, turning and sleep share a blended body rig; head and tail follow through instead of changing poses in a single frame. The live page has separate scoped hero and playground companions, both present before visitors use the controls.

## Made for actual websites

- Document coordinates keep perches stable during scrolling. Animation continues while visitors scroll.
- Resize and content changes refresh bounded geometry; the whole DOM is not measured on every frame.
- A viewport-sized canvas caps device pixel ratio and pixel count.
- Hidden tabs suspend animation. System reduced-motion preferences render a static cat and disable autonomous movement.
- Touch visitors can use the demo’s ordinary action buttons or gently tap the cat; there are no required hover-only controls.
- Every instance owns its listeners, observers and animation frame, with idempotent teardown.

![Black Cat mobile playground](https://cat.fluri.xyz/previews/black-cat-mobile.png)

## Licence

Black Cat is commercial from **0.1.0**. A **€19 one-time Fluri lifetime licence** includes all current and future themes on unlimited personal, business and client websites. Private non-production evaluation is allowed before purchase. Production use and client delivery require a licence. Standalone library resale and public source redistribution are prohibited. [Read the full licence](https://fluri.xyz/license/).

`LICENSE-MIT-LEGACY` preserves notices for historical editions of other Fluri themes. **Black Cat has no MIT edition.** Third-party development tools and the demo’s DM Sans font retain their own licences.

Contact **fluritheme@gmail.com** to arrange a licence. Automated checkout is not available yet.

## Development

```sh
pnpm install
pnpm dev
pnpm check
```

`pnpm build` creates ESM and TypeScript declarations. `pnpm build:site` builds the demo and evaluation archive. `pnpm release:check` checks archive contents, SSR imports and licensing. Browser checks cover Chromium, Firefox, Safari/WebKit and a mobile viewport, including scrolling, hiding, click-through, reduced motion and teardown.

Created by [František Gejdoš](https://fluri.xyz/founder/), founder of Fluri Themes.
